<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AUTH — প্রবেশ করুন</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --black: #0a0a0a;
            --white: #f5f5f0;
            --gray-100: #e8e8e3;
            --gray-200: #d0d0ca;
            --gray-400: #888880;
            --gray-600: #555550;
            --gray-800: #2a2a28;
            --accent: #f5f5f0;
            --border: rgba(245,245,240,0.12);
            --border-strong: rgba(245,245,240,0.3);
            --glow: rgba(245,245,240,0.05);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            background: var(--black);
            color: var(--white);
            font-family: 'Space Mono', monospace;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* ─── NOISE TEXTURE OVERLAY ─── */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
            pointer-events: none;
            z-index: 0;
            opacity: 0.4;
        }

        /* ─── GRID BACKGROUND ─── */
        body::after {
            content: '';
            position: fixed;
            inset: 0;
            background-image: 
                linear-gradient(rgba(245,245,240,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(245,245,240,0.03) 1px, transparent 1px);
            background-size: 60px 60px;
            pointer-events: none;
            z-index: 0;
        }

        /* ─── NAVBAR ─── */
        nav {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
            height: 64px;
            background: rgba(10,10,10,0.85);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border);
        }

        .nav-logo {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1.4rem;
            letter-spacing: -0.02em;
            color: var(--white);
            text-decoration: none;
        }

        .nav-logo span {
            display: inline-block;
            width: 8px;
            height: 8px;
            background: var(--white);
            border-radius: 50%;
            margin-left: 4px;
            vertical-align: middle;
            animation: pulse-dot 2s ease-in-out infinite;
        }

        @keyframes pulse-dot {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.3; transform: scale(0.6); }
        }

        .nav-tabs {
            display: flex;
            gap: 4px;
            background: var(--gray-800);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 4px;
        }

        .nav-tab {
            font-family: 'Space Mono', monospace;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            padding: 8px 20px;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            background: transparent;
            color: var(--gray-400);
            transition: all 0.2s ease;
        }

        .nav-tab:hover { color: var(--white); }

        .nav-tab.active {
            background: var(--white);
            color: var(--black);
        }

        /* ─── HERO SECTION ─── */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 1;
            padding: 100px 40px 60px;
        }

        .hero-inner {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 80px;
            max-width: 1100px;
            width: 100%;
            align-items: center;
        }

        /* ─── LEFT SIDE TEXT ─── */
        .hero-text h1 {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: clamp(2.5rem, 5vw, 4rem);
            line-height: 1.05;
            letter-spacing: -0.03em;
            margin-bottom: 24px;
        }

        .hero-text h1 em {
            font-style: normal;
            display: block;
            color: var(--gray-400);
        }

        .hero-text p {
            color: var(--gray-400);
            font-size: 0.875rem;
            line-height: 1.8;
            max-width: 360px;
            margin-bottom: 40px;
        }

        .feature-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .feature-list li {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.8rem;
            color: var(--gray-400);
            letter-spacing: 0.04em;
        }

        .feature-list li::before {
            content: '';
            width: 20px;
            height: 1px;
            background: var(--gray-600);
            flex-shrink: 0;
        }

        /* ─── CARD ─── */
        .auth-card {
            background: rgba(245,245,240,0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }

        .auth-card::before {
            content: '';
            position: absolute;
            top: -1px;
            left: 20%;
            right: 20%;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(245,245,240,0.5), transparent);
        }

        /* ─── PANEL SWITCHER ─── */
        .panel { display: none; animation: fadeUp 0.35s ease; }
        .panel.active { display: block; }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .panel-title {
            font-family: 'Syne', sans-serif;
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 6px;
            letter-spacing: -0.02em;
        }

        .panel-sub {
            font-size: 0.75rem;
            color: var(--gray-400);
            margin-bottom: 32px;
            letter-spacing: 0.04em;
        }

        /* ─── FORM ELEMENTS ─── */
        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 0.7rem;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: var(--gray-400);
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            background: rgba(245,245,240,0.04);
            border: 1px solid var(--border-strong);
            border-radius: 6px;
            padding: 12px 16px;
            color: var(--white);
            font-family: 'Space Mono', monospace;
            font-size: 0.85rem;
            outline: none;
            transition: all 0.2s ease;
        }

        .form-input::placeholder { color: var(--gray-600); }

        .form-input:focus {
            border-color: var(--gray-200);
            background: rgba(245,245,240,0.07);
            box-shadow: 0 0 0 3px rgba(245,245,240,0.06);
        }

        .form-input.error {
            border-color: #ff6b6b;
            box-shadow: 0 0 0 3px rgba(255,107,107,0.1);
        }

        /* ─── BUTTON ─── */
        .btn {
            width: 100%;
            padding: 14px 24px;
            font-family: 'Space Mono', monospace;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
            overflow: hidden;
            margin-top: 8px;
        }

        .btn-primary {
            background: var(--white);
            color: var(--black);
        }

        .btn-primary:hover {
            background: var(--gray-100);
            transform: translateY(-1px);
            box-shadow: 0 8px 24px rgba(245,245,240,0.1);
        }

        .btn-primary:active { transform: translateY(0); }

        .btn-primary.loading {
            pointer-events: none;
            color: transparent;
        }

        .btn-primary.loading::after {
            content: '';
            position: absolute;
            width: 16px;
            height: 16px;
            border: 2px solid var(--black);
            border-top-color: transparent;
            border-radius: 50%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation: spin 0.6s linear infinite;
        }

        @keyframes spin { to { transform: translate(-50%, -50%) rotate(360deg); } }

        .btn-ghost {
            background: transparent;
            color: var(--gray-400);
            border: 1px solid var(--border-strong);
            font-size: 0.75rem;
            padding: 10px 20px;
            width: auto;
            margin-top: 0;
        }

        .btn-ghost:hover { color: var(--white); border-color: var(--gray-200); }

        /* ─── FOOTER LINKS ─── */
        .form-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
        }

        .link-btn {
            background: none;
            border: none;
            color: var(--gray-400);
            font-family: 'Space Mono', monospace;
            font-size: 0.75rem;
            cursor: pointer;
            text-decoration: underline;
            text-underline-offset: 3px;
            transition: color 0.2s;
            letter-spacing: 0.03em;
        }

        .link-btn:hover { color: var(--white); }

        /* ─── ALERT ─── */
        .alert {
            border-radius: 6px;
            padding: 12px 16px;
            font-size: 0.78rem;
            margin-bottom: 20px;
            border: 1px solid;
            display: none;
            line-height: 1.6;
        }

        .alert.show { display: block; animation: fadeUp 0.2s ease; }

        .alert-success {
            background: rgba(100,200,100,0.08);
            border-color: rgba(100,200,100,0.3);
            color: #90d090;
        }

        .alert-error {
            background: rgba(255,100,100,0.08);
            border-color: rgba(255,100,100,0.3);
            color: #ff9090;
        }

        /* ─── OTP INPUT ─── */
        .otp-group {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .otp-input {
            flex: 1;
            text-align: center;
            font-size: 1.2rem;
            font-weight: 700;
            padding: 14px 4px;
            background: rgba(245,245,240,0.04);
            border: 1px solid var(--border-strong);
            border-radius: 6px;
            color: var(--white);
            font-family: 'Space Mono', monospace;
            outline: none;
            transition: all 0.2s;
        }

        .otp-input:focus {
            border-color: var(--white);
            background: rgba(245,245,240,0.08);
        }

        /* ─── DIVIDER ─── */
        .divider {
            height: 1px;
            background: var(--border);
            margin: 24px 0;
            position: relative;
        }

        .divider span {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: var(--black);
            padding: 0 12px;
            font-size: 0.7rem;
            color: var(--gray-600);
            letter-spacing: 0.1em;
        }

        /* ─── LOGGED IN STATE ─── */
        .logged-in-panel {
            text-align: center;
            display: none;
        }

        .logged-in-panel.active { display: block; }

        .avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: var(--white);
            color: var(--black);
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }

        /* ─── STEP INDICATOR ─── */
        .steps {
            display: flex;
            gap: 8px;
            margin-bottom: 28px;
        }

        .step-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--gray-800);
            border: 1px solid var(--border-strong);
            transition: all 0.3s;
        }

        .step-dot.active { background: var(--white); border-color: var(--white); }
        .step-dot.done { background: var(--gray-600); border-color: var(--gray-600); }

        /* ─── RESPONSIVE ─── */
        @media (max-width: 768px) {
            nav { padding: 0 20px; }
            .hero-inner { grid-template-columns: 1fr; gap: 40px; }
            .hero-text { display: none; }
            .hero { padding: 80px 20px 40px; }
            .auth-card { padding: 28px 24px; }
        }
    </style>
</head>
<body>

<!-- ══ NAVBAR ══ -->
<nav>
    <a href="#" class="nav-logo">AUTH<span></span></a>
    <div class="nav-tabs" id="navTabs">
        <button class="nav-tab active" onclick="showPanel('login')">লগইন</button>
        <button class="nav-tab" onclick="showPanel('register')">রেজিস্ট্রেশন</button>
    </div>
</nav>

<!-- ══ HERO ══ -->
<section class="hero">
    <div class="hero-inner">

        <!-- Left text -->
        <div class="hero-text">
            <h1>নিরাপদ<br><em>প্রবেশাধিকার</em></h1>
            <p>একটি সুরক্ষিত, মনোক্রোম ডিজাইনের অথেনটিকেশন সিস্টেম। সহজ, দ্রুত, নির্ভরযোগ্য।</p>
            <ul class="feature-list">
                <li>bcrypt পাসওয়ার্ড এনক্রিপশন</li>
                <li>OTP ভিত্তিক পাসওয়ার্ড রিসেট</li>
                <li>PHP Session ব্যবস্থাপনা</li>
                <li>SQL Injection সুরক্ষা</li>
            </ul>
        </div>

        <!-- Auth Card -->
        <div class="auth-card">

            <!-- ══ লগইন প্যানেল ══ -->
            <div class="panel active" id="panel-login">
                <div class="panel-title">স্বাগতম</div>
                <div class="panel-sub">// আপনার অ্যাকাউন্টে প্রবেশ করুন</div>

                <div class="alert" id="login-alert"></div>

                <div class="form-group">
                    <label class="form-label">ইমেইল</label>
                    <input type="email" class="form-input" id="login-email" placeholder="you@example.com">
                </div>

                <div class="form-group">
                    <label class="form-label">পাসওয়ার্ড</label>
                    <input type="password" class="form-input" id="login-pass" placeholder="••••••••">
                </div>

                <button class="btn btn-primary" id="login-btn" onclick="doLogin()">
                    প্রবেশ করুন →
                </button>

                <div class="form-footer">
                    <button class="link-btn" onclick="showPanel('forgot')">পাসওয়ার্ড ভুলে গেছেন?</button>
                    <button class="btn btn-ghost" onclick="showPanel('register')">নতুন অ্যাকাউন্ট</button>
                </div>
            </div>

            <!-- ══ রেজিস্ট্রেশন প্যানেল ══ -->
            <div class="panel" id="panel-register">
                <div class="panel-title">অ্যাকাউন্ট তৈরি</div>
                <div class="panel-sub">// নতুন অ্যাকাউন্ট খুলুন</div>

                <div class="alert" id="reg-alert"></div>

                <div class="form-group">
                    <label class="form-label">ইউজারনেম</label>
                    <input type="text" class="form-input" id="reg-username" placeholder="username123">
                </div>

                <div class="form-group">
                    <label class="form-label">ইমেইল</label>
                    <input type="email" class="form-input" id="reg-email" placeholder="you@example.com">
                </div>

                <div class="form-group">
                    <label class="form-label">পাসওয়ার্ড</label>
                    <input type="password" class="form-input" id="reg-pass" placeholder="কমপক্ষে ৬ অক্ষর">
                </div>

                <div class="form-group">
                    <label class="form-label">পাসওয়ার্ড নিশ্চিত করুন</label>
                    <input type="password" class="form-input" id="reg-confirm" placeholder="একই পাসওয়ার্ড">
                </div>

                <button class="btn btn-primary" id="reg-btn" onclick="doRegister()">
                    অ্যাকাউন্ট খুলুন →
                </button>

                <div class="form-footer">
                    <span style="font-size:0.75rem;color:var(--gray-600);">অ্যাকাউন্ট আছে?</span>
                    <button class="btn btn-ghost" onclick="showPanel('login')">লগইন করুন</button>
                </div>
            </div>

            <!-- ══ পাসওয়ার্ড ভুলে গেছেন - Step 1 ══ -->
            <div class="panel" id="panel-forgot">
                <div class="steps">
                    <div class="step-dot active" id="step1"></div>
                    <div class="step-dot" id="step2"></div>
                    <div class="step-dot" id="step3"></div>
                </div>
                <div class="panel-title">পাসওয়ার্ড রিসেট</div>
                <div class="panel-sub">// আপনার ইমেইল দিন, কোড পাঠাব</div>

                <div class="alert" id="forgot1-alert"></div>

                <div class="form-group">
                    <label class="form-label">ইমেইল</label>
                    <input type="email" class="form-input" id="forgot-email" placeholder="registered@email.com">
                </div>

                <button class="btn btn-primary" id="forgot1-btn" onclick="sendToken()">
                    রিসেট কোড পাঠান →
                </button>

                <div class="form-footer">
                    <button class="link-btn" onclick="showPanel('login')">← লগইনে ফিরে যান</button>
                </div>
            </div>

            <!-- ══ পাসওয়ার্ড ভুলে গেছেন - Step 2 ══ -->
            <div class="panel" id="panel-forgot2">
                <div class="steps">
                    <div class="step-dot done"></div>
                    <div class="step-dot active"></div>
                    <div class="step-dot" id="step3b"></div>
                </div>
                <div class="panel-title">কোড যাচাই করুন</div>
                <div class="panel-sub">// ৬ সংখ্যার কোড দিন</div>

                <div class="alert" id="forgot2-alert"></div>

                <div class="otp-group" id="otp-boxes">
                    <input class="otp-input" maxlength="1" type="text" inputmode="numeric" oninput="otpNav(this,0)">
                    <input class="otp-input" maxlength="1" type="text" inputmode="numeric" oninput="otpNav(this,1)">
                    <input class="otp-input" maxlength="1" type="text" inputmode="numeric" oninput="otpNav(this,2)">
                    <input class="otp-input" maxlength="1" type="text" inputmode="numeric" oninput="otpNav(this,3)">
                    <input class="otp-input" maxlength="1" type="text" inputmode="numeric" oninput="otpNav(this,4)">
                    <input class="otp-input" maxlength="1" type="text" inputmode="numeric" oninput="otpNav(this,5)">
                </div>

                <button class="btn btn-primary" id="forgot2-btn" onclick="verifyToken()">
                    কোড যাচাই করুন →
                </button>
            </div>

            <!-- ══ পাসওয়ার্ড ভুলে গেছেন - Step 3 ══ -->
            <div class="panel" id="panel-forgot3">
                <div class="steps">
                    <div class="step-dot done"></div>
                    <div class="step-dot done"></div>
                    <div class="step-dot active"></div>
                </div>
                <div class="panel-title">নতুন পাসওয়ার্ড</div>
                <div class="panel-sub">// নিরাপদ পাসওয়ার্ড দিন</div>

                <div class="alert" id="forgot3-alert"></div>

                <div class="form-group">
                    <label class="form-label">নতুন পাসওয়ার্ড</label>
                    <input type="password" class="form-input" id="new-pass" placeholder="কমপক্ষে ৬ অক্ষর">
                </div>

                <div class="form-group">
                    <label class="form-label">পুনরায় পাসওয়ার্ড</label>
                    <input type="password" class="form-input" id="new-confirm" placeholder="একই পাসওয়ার্ড">
                </div>

                <button class="btn btn-primary" id="forgot3-btn" onclick="resetPassword()">
                    পাসওয়ার্ড পরিবর্তন করুন →
                </button>
            </div>

            <!-- ══ লগইন সফল প্যানেল ══ -->
            <div class="panel" id="panel-dashboard">
                <div style="text-align:center;padding:20px 0;">
                    <div class="avatar" id="user-avatar">?</div>
                    <div class="panel-title" id="user-greeting">স্বাগতম!</div>
                    <div class="panel-sub" style="margin-bottom:32px;">// আপনি সফলভাবে লগইন করেছেন</div>

                    <div style="background:rgba(245,245,240,0.04);border:1px solid var(--border);border-radius:8px;padding:20px;margin-bottom:24px;text-align:left;">
                        <div style="font-size:0.7rem;letter-spacing:0.1em;color:var(--gray-600);text-transform:uppercase;margin-bottom:8px;">Status</div>
                        <div style="font-size:0.85rem;color:#90d090;">● Active Session</div>
                    </div>

                    <button class="btn btn-primary" onclick="doLogout()" id="logout-btn">
                        লগআউট করুন →
                    </button>
                </div>
            </div>

        </div><!-- /auth-card -->
    </div><!-- /hero-inner -->
</section>

<script>
let currentForgotEmail = '';
let currentOTP = '';

// ─── প্যানেল সুইচ ───
function showPanel(name) {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.getElementById('panel-' + name).classList.add('active');

    // Navbar active state
    const tabs = document.querySelectorAll('.nav-tab');
    if (name === 'login') { tabs[0].classList.add('active'); tabs[1].classList.remove('active'); }
    else if (name === 'register') { tabs[1].classList.add('active'); tabs[0].classList.remove('active'); }
    else { tabs[0].classList.remove('active'); tabs[1].classList.remove('active'); }

    clearAlerts();
}

function clearAlerts() {
    document.querySelectorAll('.alert').forEach(a => a.classList.remove('show'));
}

function showAlert(id, message, type) {
    const el = document.getElementById(id);
    el.textContent = message;
    el.className = 'alert alert-' + type + ' show';
}

function setLoading(btnId, loading) {
    document.getElementById(btnId).classList.toggle('loading', loading);
}

// ─── POST হেল্পার ───
async function postForm(url, data) {
    const body = new URLSearchParams(data);
    const res = await fetch(url, { method: 'POST', body });
    return res.json();
}

// ─── লগইন ───
async function doLogin() {
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-pass').value;

    if (!email || !password) { showAlert('login-alert','ইমেইল ও পাসওয়ার্ড দিন','error'); return; }

    setLoading('login-btn', true);
    try {
        const res = await postForm('php/login.php', { email, password });
        if (res.success) {
            showPanel('dashboard');
            const initial = (res.username || 'U')[0].toUpperCase();
            document.getElementById('user-avatar').textContent = initial;
            document.getElementById('user-greeting').textContent = 'স্বাগতম, ' + res.username + '!';
        } else {
            showAlert('login-alert', res.message, 'error');
        }
    } catch(e) {
        showAlert('login-alert', 'সার্ভারে সমস্যা হয়েছে', 'error');
    }
    setLoading('login-btn', false);
}

// ─── রেজিস্ট্রেশন ───
async function doRegister() {
    const username = document.getElementById('reg-username').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-pass').value;
    const confirm_password = document.getElementById('reg-confirm').value;

    setLoading('reg-btn', true);
    try {
        const res = await postForm('php/register.php', { username, email, password, confirm_password });
        showAlert('reg-alert', res.message, res.success ? 'success' : 'error');
        if (res.success) {
            setTimeout(() => showPanel('login'), 2000);
        }
    } catch(e) {
        showAlert('reg-alert', 'সার্ভারে সমস্যা হয়েছে', 'error');
    }
    setLoading('reg-btn', false);
}

// ─── পাসওয়ার্ড রিসেট Step 1 ───
async function sendToken() {
    currentForgotEmail = document.getElementById('forgot-email').value.trim();
    if (!currentForgotEmail) { showAlert('forgot1-alert','ইমেইল দিন','error'); return; }

    setLoading('forgot1-btn', true);
    try {
        const res = await postForm('php/forgot_password.php', {
            action: 'send_token',
            email: currentForgotEmail
        });
        showAlert('forgot1-alert', res.message, res.success ? 'success' : 'error');

        // Demo: যদি demo_token আসে, OTP input-এ দেখাও
        if (res.success && res.demo_token) {
            currentOTP = res.demo_token;
            const boxes = document.querySelectorAll('.otp-input');
            res.demo_token.split('').forEach((d, i) => boxes[i].value = d);
            setTimeout(() => showPanel('forgot2'), 1500);
        }
    } catch(e) {
        showAlert('forgot1-alert', 'সার্ভারে সমস্যা হয়েছে', 'error');
    }
    setLoading('forgot1-btn', false);
}

// ─── OTP Navigation ───
function otpNav(input, idx) {
    input.value = input.value.replace(/[^0-9]/g, '');
    const boxes = document.querySelectorAll('.otp-input');
    if (input.value && idx < 5) boxes[idx + 1].focus();
}

// ─── পাসওয়ার্ড রিসেট Step 2 ───
async function verifyToken() {
    const boxes = document.querySelectorAll('.otp-input');
    const token = [...boxes].map(b => b.value).join('');

    if (token.length !== 6) { showAlert('forgot2-alert','৬ সংখ্যার কোড দিন','error'); return; }

    currentOTP = token;
    showPanel('forgot3');
}

// ─── পাসওয়ার্ড রিসেট Step 3 ───
async function resetPassword() {
    const new_password = document.getElementById('new-pass').value;
    const confirm_password = document.getElementById('new-confirm').value;

    if (new_password !== confirm_password) {
        showAlert('forgot3-alert','পাসওয়ার্ড মিলছে না','error'); return;
    }

    setLoading('forgot3-btn', true);
    try {
        const res = await postForm('php/forgot_password.php', {
            action: 'reset_password',
            email: currentForgotEmail,
            token: currentOTP,
            new_password,
            confirm_password
        });
        showAlert('forgot3-alert', res.message, res.success ? 'success' : 'error');
        if (res.success) setTimeout(() => showPanel('login'), 2000);
    } catch(e) {
        showAlert('forgot3-alert', 'সার্ভারে সমস্যা হয়েছে', 'error');
    }
    setLoading('forgot3-btn', false);
}

// ─── লগআউট ───
async function doLogout() {
    setLoading('logout-btn', true);
    try {
        await fetch('php/logout.php');
    } catch(e) {}
    showPanel('login');
    setLoading('logout-btn', false);
}

// Enter key সাপোর্ট
document.addEventListener('keydown', function(e) {
    if (e.key !== 'Enter') return;
    const active = document.querySelector('.panel.active');
    if (!active) return;
    if (active.id === 'panel-login') doLogin();
    else if (active.id === 'panel-register') doRegister();
    else if (active.id === 'panel-forgot') sendToken();
    else if (active.id === 'panel-forgot3') resetPassword();
});
</script>

</body>
</html>
