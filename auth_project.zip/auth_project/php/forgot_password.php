<?php
require_once 'config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$action = $_POST['action'] ?? '';

// ---- Step 1: Token পাঠানো ----
if ($action === 'send_token') {
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'সঠিক ইমেইল দিন']);
        exit;
    }

    $conn = getConnection();
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        // Security: একই message দাও
        echo json_encode(['success' => true, 'message' => 'যদি ইমেইল সঠিক হয়, রিসেট কোড পাঠানো হয়েছে।']);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // পুরনো token মুছে দাও
    $del = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
    $del->bind_param("s", $email);
    $del->execute();
    $del->close();

    // ৬ সংখ্যার OTP তৈরি করো
    $token  = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));

    $ins = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
    $ins->bind_param("sss", $email, $token, $expiry);
    $ins->execute();
    $ins->close();
    $conn->close();

    // ডেমো: বাস্তবে PHPMailer দিয়ে মেইল পাঠাও
    // এখানে token সরাসরি দেখাচ্ছি demo উদ্দেশ্যে
    echo json_encode([
        'success' => true,
        'message' => 'রিসেট কোড পাঠানো হয়েছে। (Demo কোড: ' . $token . ')',
        'demo_token' => $token  // production-এ এটা সরাও
    ]);
    exit;
}

// ---- Step 2: Token যাচাই ও নতুন পাসওয়ার্ড ----
if ($action === 'reset_password') {
    $email    = trim($_POST['email'] ?? '');
    $token    = trim($_POST['token'] ?? '');
    $password = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (empty($email) || empty($token) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'সব তথ্য দিন']);
        exit;
    }

    if ($password !== $confirm) {
        echo json_encode(['success' => false, 'message' => 'পাসওয়ার্ড মিলছে না']);
        exit;
    }

    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে']);
        exit;
    }

    $conn = getConnection();
    $stmt = $conn->prepare("SELECT id FROM password_resets WHERE email = ? AND token = ? AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'কোড ভুল বা মেয়াদ শেষ হয়েছে']);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    $hashed = password_hash($password, PASSWORD_BCRYPT);

    $upd = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $upd->bind_param("ss", $hashed, $email);
    $upd->execute();
    $upd->close();

    $del = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
    $del->bind_param("s", $email);
    $del->execute();
    $del->close();

    $conn->close();

    echo json_encode(['success' => true, 'message' => 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে! এখন লগইন করুন।']);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
