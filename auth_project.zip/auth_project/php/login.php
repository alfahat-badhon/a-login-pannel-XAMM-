<?php
require_once 'config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'ইমেইল ও পাসওয়ার্ড দিন']);
    exit;
}

$conn = getConnection();

$stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($id, $username, $hashedPassword);
$stmt->fetch();
$stmt->close();

if (!$id || !password_verify($password, $hashedPassword)) {
    echo json_encode(['success' => false, 'message' => 'ইমেইল বা পাসওয়ার্ড ভুল']);
    $conn->close();
    exit;
}

// Session সেট করো
$_SESSION['user_id']   = $id;
$_SESSION['username']  = $username;

echo json_encode([
    'success'  => true,
    'message'  => 'লগইন সফল! স্বাগতম, ' . $username,
    'username' => $username
]);

$conn->close();
?>
