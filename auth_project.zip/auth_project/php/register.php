<?php
require_once 'config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm  = $_POST['confirm_password'] ?? '';

// ভ্যালিডেশন
if (empty($username) || empty($email) || empty($password) || empty($confirm)) {
    echo json_encode(['success' => false, 'message' => 'সব ঘর পূরণ করুন']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'সঠিক ইমেইল দিন']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে']);
    exit;
}

if ($password !== $confirm) {
    echo json_encode(['success' => false, 'message' => 'পাসওয়ার্ড মিলছে না']);
    exit;
}

$conn = getConnection();

// Duplicate check
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
$stmt->bind_param("ss", $email, $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'এই ইমেইল বা ইউজারনেম ইতোমধ্যে ব্যবহৃত হয়েছে']);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// পাসওয়ার্ড হ্যাশ করো
$hashed = password_hash($password, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $email, $hashed);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'রেজিস্ট্রেশন সফল হয়েছে! এখন লগইন করুন।']);
} else {
    echo json_encode(['success' => false, 'message' => 'রেজিস্ট্রেশন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।']);
}

$stmt->close();
$conn->close();
?>
