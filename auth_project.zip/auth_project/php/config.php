<?php
// ডেটাবেজ কনফিগারেশন
define('DB_HOST', 'localhost');
define('DB_USER', 'root');         // XAMPP default user
define('DB_PASS', '');             // XAMPP default password (empty)
define('DB_NAME', 'auth_system');

// কানেকশন তৈরি
function getConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]));
    }
    $conn->set_charset("utf8");
    return $conn;
}

// Session শুরু
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
